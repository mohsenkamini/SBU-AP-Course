public enum CardTypes {
    Red, Blue, Black, White
}
