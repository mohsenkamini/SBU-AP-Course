public enum CardRanks {
    One, Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten
}
