public class EcoBoost extends Engine{
    // public int score = 250+100;
    // public int price = 500+200;
    public int score () {
        return 250+100;
    }
    public int price () {
        return 500+200;
    }

}
