public class Street extends Wheel{
    // public int score = 100+50;
    // public int price = 200+100;

    public int score () {
        return 100+50;
    }
    public int price () {
        return 200+100;
    }
}
