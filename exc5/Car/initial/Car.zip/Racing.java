public class Racing extends Wheel{
    // public int score = 100+150;
    // public int price = 200+300;
    
    public int score () {
        return 100+150;
    }
    public int price () {
        return 200+300;
    }
}
