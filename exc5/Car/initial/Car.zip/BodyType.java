public class BodyType {
    public int score () {
        return 100;
    }
    public int price () {
        return 1000;
    }
}