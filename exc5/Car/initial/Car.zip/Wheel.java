public class Wheel {
    // public int score = 100;
    // public int price = 200;
    
    public int score () {
        return 100;
    }
    public int price () {
        return 200;
    }
}