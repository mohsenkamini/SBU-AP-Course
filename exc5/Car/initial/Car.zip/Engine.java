public class Engine {

    // public int score = 250;
    // public int price = 500;
    
    public int score () {
        return 250;
    }
    public int price () {
        return 500;
    }
}
