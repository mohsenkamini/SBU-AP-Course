public class TwinTurbo extends Engine{
    // public int score = 250+150;
    // public int price = 500+500;
    
    public int score () {
        return 250+150;
    }
    public int price () {
        return 500+500;
    }
}