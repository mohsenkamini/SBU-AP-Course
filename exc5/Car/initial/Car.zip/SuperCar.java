public class SuperCar extends BodyType{
    // public int score = 100+100;
    // public int price = 1000+1500;
    
    public int score () {
        return 100+100;
    }
    public int price () {
        return 1000+1500;
    }
}
