public class BodyType {

}