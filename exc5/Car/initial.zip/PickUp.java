public class PickUp extends BodyType{
}