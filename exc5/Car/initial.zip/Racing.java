public class Racing extends Wheel{

}
