public class Wheel {
}