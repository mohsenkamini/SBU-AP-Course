public class Car {
    BodyType body;
    Engine engine;
    Wheel wheel;
    int tax = 100;

    public Car(BodyType body, Engine engine, Wheel wheel) {
    }

    void setTax(int tax) {
    }

    Car(int budget) {


    }

    public int getScore() {

    }

    public int getPrice() {

    }

}





