public class Street extends Wheel{

}
