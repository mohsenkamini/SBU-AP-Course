public class SuperCar extends BodyType{

}
