public class InvalidNumberException extends java.lang.Exception {
    InvalidNumberException(String s) {
        super(s);
    }
}