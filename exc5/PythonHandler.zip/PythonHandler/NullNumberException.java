public class NullNumberException extends java.lang.Exception {
    NullNumberException(String s) {
        super(s);
    }
}
