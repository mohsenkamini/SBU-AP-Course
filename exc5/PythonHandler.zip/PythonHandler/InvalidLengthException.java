public class InvalidLengthException extends java.lang.Exception {
    InvalidLengthException(String s) {
        super(s);
    }
}
