
public class ProtocolException extends java.lang.Exception {
    public ProtocolException(String s) {
        super(s);
    }
}