public class SecondLevelDomainException extends java.lang.Exception {
    public SecondLevelDomainException(String s) {
        super(s);
    }
}
