public class TopLevelDomainException extends java.lang.Exception {
    public TopLevelDomainException(String s) {
        super(s);
    }
}